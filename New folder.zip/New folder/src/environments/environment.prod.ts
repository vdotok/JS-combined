export const environment = {
  production: true,
  apiBaseUrl : 'https://q-tenant.vdotok.dev/API/v0/'
};
